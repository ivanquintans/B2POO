package B3E1;

public class ComediaRomantica extends Comedia {

    public ComediaRomantica(String nombre, Integer anho, Integer duracion, String director, float recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }

}

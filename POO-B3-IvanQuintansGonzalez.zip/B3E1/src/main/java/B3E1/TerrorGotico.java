package B3E1;

public class TerrorGotico extends Terror{

    public TerrorGotico(String nombre, Integer anho, Integer duracion, String director, float recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }
}

package B3E1;

public class Ficcion extends Accion{

    public Ficcion(String nombre, Integer anho, Integer duracion, String director, float recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }
}

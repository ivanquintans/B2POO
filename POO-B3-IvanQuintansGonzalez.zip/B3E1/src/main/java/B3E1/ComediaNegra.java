package B3E1;

public class ComediaNegra extends Comedia{

    public ComediaNegra(String nombre, Integer anho, Integer duracion, String director, float recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }
}

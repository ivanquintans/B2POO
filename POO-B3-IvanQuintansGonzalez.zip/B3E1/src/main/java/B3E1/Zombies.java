package B3E1;

public class Zombies extends Terror{

    public Zombies(String nombre, Integer anho, Integer duracion, String director, float recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }
}

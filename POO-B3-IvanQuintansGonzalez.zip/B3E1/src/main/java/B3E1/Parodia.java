package B3E1;

public class Parodia extends Comedia {

    public Parodia(String nombre, Integer anho, Integer duracion, String director, float recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }
}

package B3E1;

public class Thriller extends Accion{

    public Thriller(String nombre, Integer anho, Integer duracion, String director, float recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }
}

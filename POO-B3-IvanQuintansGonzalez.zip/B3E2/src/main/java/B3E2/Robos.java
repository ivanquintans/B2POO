package B3E2;

import java.util.HashMap;

public final class Robos extends Accion{


    public Robos(String nombre, Integer anho, Integer duracion, Director director, HashMap<String, Float> recaudacion) {
        super(nombre, anho, duracion, director, recaudacion);
    }
}
